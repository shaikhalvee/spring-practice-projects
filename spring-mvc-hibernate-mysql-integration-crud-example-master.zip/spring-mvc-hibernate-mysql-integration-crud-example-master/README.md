#Spring MVC Hibernate Mysql integration CRUD Example 

Guide

This is a part of the tutorial http://javabycode.com/spring-framework-tutorial/spring-mvc-tutorial/spring-mvc-hibernate-mysql-integration-crud-example-tutorial.html

What you'll need

JDK 1.7 or later
Maven 3 or later
Spring MVC 4.2.6.RELEASE  
Build

mvn clean install    
